# Welcome to the Keeping Green Source
This repository includes the frontend and backend code for the Keeping Green app. The purpose of this web app is to make it easy to find trash and recycling bins throughout Medgar Evers buildings with simple instructions and pictures.

## Buildings

### Bedford Building

#### Floors
- Library Sub
- Library Main
- Library 2nd
- 1st
- 2nd

### AB-1 Building
#### Floors
- Sub
- Main
- 2nd
- 3rd
- 4th
- 5th